package com.edu.eventbooking.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.edu.eventbooking.dao.ApiResponse;
import com.edu.eventbooking.dao.Partner;
import com.edu.eventbooking.error.GlobalException;
import com.edu.eventbooking.error.UserNotFoundExceptionHandler;
import com.edu.eventbooking.repository.PartnerRepository;
import com.edu.eventbooking.service.PartnerService;


@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class PartnerController {
	
	
	//injecting the respective service classes and interfaces
	@Autowired
	private PartnerService partnerService;

	
	@Autowired
	private PartnerRepository partnerRepository;


	/*
	method to register as partner
	
	http://localhost:8080/registerPartner
	*/
	@PostMapping("/registerPartner")
	public ResponseEntity<ApiResponse<Partner>>  registerPartner( @RequestBody Partner partner) throws GlobalException{
		Partner partner_obj=partnerRepository.findbyPancard(partner.getPancard());
		if(partner_obj!=null) {
			ApiResponse<Partner> apiResponse = new ApiResponse<>("Partner exists with mobile number : " + partner.getPancard(), partner_obj);
			return new ResponseEntity<>(apiResponse, HttpStatus.BAD_REQUEST);
		} else {
			Partner savedPartner = partnerService.registerPartner(partner);
			ApiResponse<Partner> apiResponse = new ApiResponse<>("Partner saved successfully", savedPartner);
			return new ResponseEntity<>(apiResponse, HttpStatus.CREATED);
		}

	}


	//method to retrieve all partners
	@GetMapping("/getAllPartners")
	public List<Partner> getAllPartners() throws GlobalException {
		return partnerService.getAllPartners();

	}

	
	/*
	delete partner by id
	
	http://localhost:8080/deletePartnerById/{id}
	*/
	@DeleteMapping("/deletePartnerById/{id}")
	public ResponseEntity<ApiResponse<Partner>> deletePartnerById(@PathVariable("id") Integer id ) throws UserNotFoundExceptionHandler, GlobalException {
		Partner partner_obj=partnerRepository.findById(id).get();
		
		if(partner_obj != null) {
			System.out.println("Partner exists");
			Partner savedPartner = partnerService.deletePartnerById(id);
			ApiResponse<Partner> apiResponse = new ApiResponse<>(" Deleted Partner with mobile number : " + id, savedPartner);
			return new ResponseEntity<>(apiResponse, HttpStatus.OK);
		} else {
			System.out.println("Partner doesn't exists");
			ApiResponse<Partner> apiResponse = new ApiResponse<>("Partner not found with mobile number : " + id, null);
			return new ResponseEntity<>(apiResponse, HttpStatus.NOT_FOUND);
		}
	}

	
	/*
	method to get details by pancard
	
	http://localhost:8080/findbyPancard/{pan}
	*/
	@GetMapping("/findbyPancard/{pan}")
	public ResponseEntity<ApiResponse<Partner>> findbyPancard(@PathVariable("pan") String pancard) throws UserNotFoundExceptionHandler, GlobalException {
		Partner partner_obj=partnerRepository.findbyPancard(pancard);
		
		if(partner_obj != null) {
			System.out.println("Partner exists");
			Partner savedPartner = partnerService.findbyPancard(pancard);
			ApiResponse<Partner> apiResponse = new ApiResponse<>("Partner exists with pancard number : " + pancard, savedPartner);
			return new ResponseEntity<>(apiResponse, HttpStatus.FOUND);
		} else {
			System.out.println("Partner doesn't exists");
			ApiResponse<Partner> apiResponse = new ApiResponse<>("Partner not found with pancard number : " + pancard, null);
			return new ResponseEntity<>(apiResponse, HttpStatus.NOT_FOUND);
		}
	}





}
