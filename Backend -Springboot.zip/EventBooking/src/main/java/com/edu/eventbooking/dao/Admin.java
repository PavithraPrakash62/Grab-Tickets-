package com.edu.eventbooking.dao;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

@Entity
public class Admin {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer adminId;
	
	@NotBlank(message = "Admin Name shouldn't be blank")
	@Pattern(regexp = "^[a-zA-Z ]*$", message = "Admin Name should contain only alphabets")
	@Column(length = 60, unique = true)
	private String adminUserName;
	
	@NotBlank(message = "Admin Password shouldn't be blank")
	@Pattern(regexp = "^(?=.*[A-Za-z])(?=.*[0-9])(?=.*[!@#$&*]).{8,}$", 
	message = "Admin Password should contain Minimum eight characters, at least one letter, one number and one special character")
	@Column( length=60)
	private String adminPassword;

	public Admin() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Admin(Integer adminId,
			@NotBlank(message = "Admin Name shouldn't be blank") @Pattern(regexp = "^[a-zA-Z ]*$", message = "Admin Name should contain only alphabets") String adminUserName,
			@NotBlank(message = "Admin Password shouldn't be blank") @Pattern(regexp = "^(?=.*[A-Za-z])(?=.*[0-9])(?=.*[!@#$&*]).{8,}$", message = "Admin Password should contain Minimum eight characters, at least one letter, one number and one special character") String adminPassword) {
		super();
		this.adminId = adminId;
		this.adminUserName = adminUserName;
		this.adminPassword = adminPassword;
	}

	public Integer getAdminId() {
		return adminId;
	}
	
	public void setAdminId(Integer adminId) {
		this.adminId = adminId;
	}

	public String getAdminUserName() {
		return adminUserName;
	}

	public void setAdminUserName(String adminUserName) {
		this.adminUserName = adminUserName;
	}

	public String getAdminPassword() {
		return adminPassword;
	}

	public void setAdminPassword(String adminPassword) {
		this.adminPassword = adminPassword;
	}

	@Override
	public String toString() {
		return " Admin [adminId=" + adminId + ", adminUserName=" + adminUserName + ", adminPassword=" + adminPassword
				+ "]";
	}
	
}
