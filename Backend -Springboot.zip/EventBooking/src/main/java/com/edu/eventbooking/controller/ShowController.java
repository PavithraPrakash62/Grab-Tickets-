package com.edu.eventbooking.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.edu.eventbooking.dao.ApiResponse;
import com.edu.eventbooking.dao.Shows;
import com.edu.eventbooking.dao.Venue;
import com.edu.eventbooking.error.UserNotFoundExceptionHandler;
import com.edu.eventbooking.repository.ShowsRepository;
import com.edu.eventbooking.repository.VenueRepository;
import com.edu.eventbooking.service.ShowsService;
@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class ShowController {


	@Autowired
	private  ShowsService showsService;

	@Autowired
	private VenueRepository venueRepository;

	@Autowired
	private ShowsRepository showsRepository;

//	@PosttMapping("/addShow")
//	public ResponseEntity<Shows> addShow(@Valid@RequestBody Shows show){
//		Shows show_obj = showsRepository.findByShowname(show.getShowname());
//		if(show_obj!=null) {
//			return ResponseEntity.badRequest().body(null);
//		}else {
//			Shows newshow=showsService.addShow(show);
//			return new ResponseEntity<>(newshow, HttpStatus.CREATED);
//		}
//	}
	
	@PutMapping("/addShow/{venue}/{address}")
	public ResponseEntity<Shows> addShow(@Valid@RequestBody Shows show,@PathVariable("venue") String venue, @PathVariable("address") String address){
		Shows show_obj = showsRepository.findByShowname(show.getShowname());
		if(show_obj!=null) {
			return ResponseEntity.badRequest().body(null);
		}else {
			Shows newshow=showsService.addShow(show);
			Venue savedvenue= venueRepository.findByVenueStreet(venue, address);
			newshow.setVenue(savedvenue);
			showsRepository.save(newshow);
			Shows updateshow=showsRepository.findByShowname(newshow.getShowname());
			
		return new ResponseEntity<>(updateshow, HttpStatus.CREATED);
		}
	}


	@DeleteMapping("/deleteShow/{id}")
	public ResponseEntity<Shows> deleteShow(@PathVariable("id") Integer id, Shows show ) throws UserNotFoundExceptionHandler {
		Shows show_obj = showsRepository.findById(id).get();

		if(show_obj != null) {
			Shows savedShows = showsService.deleteShow(id,show);
			return new ResponseEntity<>(savedShows, HttpStatus.OK);
		} else {
			System.out.println("Show doesn't exists");
			return ResponseEntity.badRequest().body(null);
		}
	}


	// this allows user to see the list of allshows with Theatre details
	@GetMapping("/getAllShows")
	public ResponseEntity<List<Shows>> getAllShows() {
		List<Shows> showslist=showsRepository.findAll();
		if(showslist!=null) {
			return new ResponseEntity<List<Shows>>(showslist, HttpStatus.OK);
		}
		else 
		{
			return ResponseEntity.badRequest().body(null);
		}
	}

	@PutMapping("/setShowtoVenue/{show}/{venue}/{address}")
	public ResponseEntity<Shows> setShowtoVenue(@PathVariable("show") String showname,@PathVariable("venue") String venue, @PathVariable("address") String address ) throws UserNotFoundExceptionHandler {
		Shows show_obj = showsRepository.findByShowname(showname);

		if(show_obj != null) {
			Venue savedvenue= venueRepository.findByVenueStreet(venue, address);
			show_obj.setVenue(savedvenue);
			showsRepository.save(show_obj);
			Shows updateshow=showsRepository.findByShowname(showname);
			//			Shows updateshow= showsService.setVenuetoShow(showname, venue, address);
			return new ResponseEntity<>(updateshow , HttpStatus.OK);
		} else {
			System.out.println("Show doesn't exists");
			return  ResponseEntity.badRequest().body(null);
		}
	}


	@GetMapping("/getShowById/{id}")
	public ResponseEntity<Shows> getShowById(@Valid @PathVariable("id") Integer id) {
		System.out.println("sending 1show");
		Shows existingShow=showsRepository.findById(id).get();
		if(existingShow!=null) {
			return new ResponseEntity<Shows>(existingShow,HttpStatus.OK);
		}
		else {
		return  ResponseEntity.badRequest().body(null);
	
		}
		}

	@GetMapping("/getShowByLoc/{loc}")
	public ResponseEntity<List<Shows>> getShowByLoc(@PathVariable("loc") String location) {
		
		List<Shows> showlist= showsRepository.findbyLoc(location);
		if(showlist!=null) {
			return new ResponseEntity<List<Shows>>(showlist,HttpStatus.OK);
		}
		else {
			return  ResponseEntity.badRequest().body(null);
		
			}
	}

}
