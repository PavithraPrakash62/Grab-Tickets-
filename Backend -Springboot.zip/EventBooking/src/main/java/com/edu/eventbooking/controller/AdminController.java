package com.edu.eventbooking.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.edu.eventbooking.dao.Admin;
import com.edu.eventbooking.dao.ApiResponse;
import com.edu.eventbooking.error.UserNotFoundExceptionHandler;
import com.edu.eventbooking.repository.AdminRepository;
import com.edu.eventbooking.service.AdminService;


@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/admin")
public class AdminController {
	
	
	@Autowired
	private AdminService adminService;
	
	
	@Autowired
	private AdminRepository adminRepository;
	
	
	/*
	http://localhost:8080/admin/save
	*/
	@PostMapping("/save")
	public ResponseEntity<ApiResponse<Admin>> saveAdmin(@RequestBody @Valid Admin admin) {
		Admin admin_obj = adminRepository.getAdminByUserName(admin.getAdminUserName());
		
		if(admin_obj != null) {
			ApiResponse<Admin> apiResponse = new ApiResponse<>("Admin already existswith user name : " + admin.getAdminUserName(), admin_obj);
			return new ResponseEntity<>(apiResponse, HttpStatus.BAD_REQUEST);
		} else {
			Admin savedAdmin = adminService.saveAdmin(admin);
			ApiResponse<Admin> apiResponse = new ApiResponse<>("Admin saved successfully", savedAdmin);
			return new ResponseEntity<>(apiResponse, HttpStatus.CREATED);
		}
	}
	
	
	/*
	http://localhost:8080/admin/updateby/{username}
	*/
	@PutMapping("/updateby/{username}")
	public ResponseEntity<ApiResponse<Admin>> updateByAdminId(@PathVariable("username") String adminUserName, @RequestBody @Valid Admin admin) throws UserNotFoundExceptionHandler {
		Admin admin_obj = adminRepository.getAdminByUserName(adminUserName);
		
		if(admin_obj != null) {
			System.out.println("Admin Exists");
			Admin savedAdmin = adminService.updateByAdminId(adminUserName, admin);
			ApiResponse<Admin> apiResponse = new ApiResponse<>("Admin updated successfully with user name : " + adminUserName, savedAdmin);
			return new ResponseEntity<>(apiResponse, HttpStatus.ACCEPTED);
		} else {
			System.out.println("Admin doesn't exists");
			ApiResponse<Admin> apiResponse = new ApiResponse<>("Admin not found with user name : " + adminUserName, null);
			return new ResponseEntity<>(apiResponse, HttpStatus.NOT_FOUND);
		}

	}
	
	
	/*
	http://localhost:8080/admin/getall
	*/
	@GetMapping("/getall")
	public ResponseEntity<List<Admin>> getAdmin(){
		return ResponseEntity.ok(adminService.getAdmin());
	}
	
	
	/*
	http://localhost:8080/admin/findby/{username}
	*/
	@GetMapping("/findby/{username}")
	public ResponseEntity<ApiResponse<Admin>> findByAdminId(@PathVariable("username") String adminUserName) throws UserNotFoundExceptionHandler{
		Admin admin_obj = adminRepository.getAdminByUserName(adminUserName);
		
		if(admin_obj != null) {
			System.out.println("Admin exists");
			Admin savedAdmin = adminService.findByAdminId(adminUserName);
			ApiResponse<Admin> apiResponse = new ApiResponse<>("Admin exists with user name : " + adminUserName, savedAdmin);
			return new ResponseEntity<>(apiResponse, HttpStatus.FOUND);
		} else {
			System.out.println("Admin doesn't exists");
			ApiResponse<Admin> apiResponse = new ApiResponse<>("Admin not found with user name : " + adminUserName, null);
			return new ResponseEntity<>(apiResponse, HttpStatus.NOT_FOUND);
		}
		
	}
	
	
	/*
	http://localhost:8080/admin/deleteall
	*/
	@DeleteMapping("/deleteall")
	public ResponseEntity<String> deleteAdmin(){
		return ResponseEntity.ok(adminService.deleteAdmin());
	}
	
	
	/*
	http://localhost:8080/admin/deleteby/{username}
	*/
	@DeleteMapping("/deleteby/{username}")
	public ResponseEntity<ApiResponse<Admin>> deleteByAdminId(@PathVariable("username") String adminUserName) throws UserNotFoundExceptionHandler{
		Admin admin_obj = adminRepository.getAdminByUserName(adminUserName);
		
		if(admin_obj != null) {
			System.out.println("Admin exists");
			Admin savedAdmin = adminService.deleteByAdminId(adminUserName);
			ApiResponse<Admin> apiResponse = new ApiResponse<>("Deleted admin with user name : " + adminUserName, savedAdmin);
			return new ResponseEntity<>(apiResponse, HttpStatus.OK);
		} else {
			System.out.println("Admin doesn't exists");
			ApiResponse<Admin> apiResponse = new ApiResponse<>("Admin not found with user name : " + adminUserName, null);
			return new ResponseEntity<>(apiResponse, HttpStatus.NOT_FOUND);
		}
		
	}

	
}
