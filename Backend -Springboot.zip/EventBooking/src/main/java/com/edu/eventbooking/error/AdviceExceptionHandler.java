package com.edu.eventbooking.error;

import java.util.HashMap;
import java.util.Map;
import java.util.NoSuchElementException;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;

import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;


@RestControllerAdvice
public class AdviceExceptionHandler {

	@ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
	@ExceptionHandler(UserNotFoundExceptionHandler.class)
	public Map<String, String> handleUserNotFound(UserNotFoundExceptionHandler ex){
		Map<String, String> errorMap = new HashMap<>();
		errorMap.put("errorMessage", ex.getMessage());
		return errorMap;
	}

	@ResponseStatus(HttpStatus.BAD_REQUEST)
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public Map<String, String> handleInvalidArgument(MethodArgumentNotValidException ex){
		Map<String, String> errorMap = new HashMap<>();
		ex.getBindingResult().getFieldErrors().forEach(error ->{
			errorMap.put(error.getField(), error.getDefaultMessage());
		});
		return errorMap;
	}

	@ResponseStatus(HttpStatus.BAD_REQUEST)
	@ExceptionHandler(DataIntegrityViolationException.class)
	public Map<String, String> handleDataIntegrityViolation(DataIntegrityViolationException ex) {
		Map<String, String> errorMap = new HashMap<>();

		Throwable cause = ex.getRootCause();

		if (cause instanceof ConstraintViolationException) {
			ConstraintViolationException constraintViolationException = (ConstraintViolationException) cause;

			for (ConstraintViolation<?> violation : constraintViolationException.getConstraintViolations()) {
				String fieldName = violation.getPropertyPath().toString();
				String message = violation.getMessage();
				errorMap.put(fieldName, message);
			}
		} else {
			errorMap.put("error", "Data integrity violation. Please check your input.");
		}

		return errorMap;
	}
	
	@ExceptionHandler(NoSuchElementException.class)
	public Map<String, String> handleNoSuchElement(NoSuchElementException ex){
		Map<String, String> errorMap = new HashMap<>();
		errorMap.put("errorMessage : Check The Input Value", ex.getMessage());
		return errorMap;
	}

}
