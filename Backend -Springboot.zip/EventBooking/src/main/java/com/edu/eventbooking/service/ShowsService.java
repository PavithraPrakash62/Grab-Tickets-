package com.edu.eventbooking.service;

import java.util.List;

import javax.validation.Valid;

import org.springframework.http.ResponseEntity;

import com.edu.eventbooking.dao.Shows;



public interface ShowsService {

	Shows addShow(Shows show);
	
	Shows deleteShow(Integer id, Shows show);

	List<Shows> getAllShows();

	Shows updateShowName(String showname, Integer partnerid);

	Shows setShowToHost(Integer hostid, Integer showid);

	Shows setVenuetoShow(String showname, String venue, String address);

	Shows getShowById( Integer id);
	

	
	
}
