package com.edu.eventbooking.service;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.edu.eventbooking.dao.Partner;
import com.edu.eventbooking.error.GlobalException;

public interface PartnerService {

	Partner registerPartner(Partner partner) throws GlobalException;

	List<Partner> getAllPartners() throws GlobalException;

	Partner findbyPancard(String pancard) throws GlobalException;

	Partner deletePartnerById(Integer id) throws GlobalException;

	
}
