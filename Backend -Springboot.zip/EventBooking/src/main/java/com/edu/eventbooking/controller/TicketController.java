package com.edu.eventbooking.controller;

import java.util.List;


import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.edu.eventbooking.dao.ApiResponse;
import com.edu.eventbooking.dao.Shows;
import com.edu.eventbooking.dao.Ticket;
import com.edu.eventbooking.dao.User;
import com.edu.eventbooking.repository.ShowsRepository;
import com.edu.eventbooking.repository.TicketRepository;
import com.edu.eventbooking.repository.UserRepository;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
class TicketController {


	@Autowired
	private TicketRepository ticketRepository;


	@Autowired
	private ShowsRepository showsRepository;


	@Autowired
	private UserRepository userRepository;


//	@PostMapping("/bookTicket")
//	public ResponseEntity<Ticket> bookTicket(@Valid @RequestBody Ticket ticket) {
//		Shows show_obj=showsRepository.findByShowname(ticket.getShowname());
//
//		if(show_obj!=null && show_obj.getAvailableseats()>=ticket.getSeats()) {
//			show_obj.setAvailableseats(show_obj.getAvailableseats()-ticket.getSeats());
//			Ticket savedTicket = ticketRepository.save(ticket);
//			return new ResponseEntity<>(savedTicket, HttpStatus.CREATED);
//		} else {
//			return ResponseEntity.badRequest().body(null);
//		}
//	}

	@PutMapping("/bookTicket/{email}")
	public ResponseEntity<Ticket> bookTicket( @PathVariable("email") String email,@Valid @RequestBody Ticket ticket) {
		Shows show_obj=showsRepository.findByShowname(ticket.getShowname());

		if(show_obj!=null && show_obj.getAvailableseats()>=ticket.getSeats()) {
			show_obj.setAvailableseats(show_obj.getAvailableseats()-ticket.getSeats());
			Ticket savedTicket = ticketRepository.save(ticket);
			User user=userRepository.findbyEmail(email);
			savedTicket.setUser(user);
			ticketRepository.save(savedTicket);
			System.out.println("booked");
			return new ResponseEntity<>(savedTicket, HttpStatus.OK);
		} else {
			return ResponseEntity.badRequest().body(null);
		}
	}
	
	
	

	@GetMapping("/bookingHistory")
	public ResponseEntity<List<Ticket>> bookinghistory(){
		if(ticketRepository.findAll()!=null) {
			List<Ticket> bookings=ticketRepository.findAll();
			return new ResponseEntity<List<Ticket>>(bookings,HttpStatus.OK);
		}
		return  ResponseEntity.badRequest().body(null);
	}


	@PutMapping("/setTicketToUser/{bookingid}/{email}")
	public ResponseEntity<Ticket> setTicketToUser(@PathVariable("bookingid") String bookingid, @PathVariable("email") String email) {
		User bookeduser=userRepository.findbyEmail(email);
		Ticket bookedticket=ticketRepository.findbyBookingId(bookingid);

		if(bookeduser!=null && bookedticket!=null) {
			bookedticket.setUser(bookeduser);
			Ticket savedTicket = ticketRepository.save(bookedticket);

			return new ResponseEntity<>(savedTicket, HttpStatus.ACCEPTED);
		} else {
			return  ResponseEntity.badRequest().body(null);
		}
	}
	
	@GetMapping("/bookingHistoryById/{uid}")
	private ResponseEntity<List<Ticket>> bookingHistoryById(@PathVariable("uid") Integer uid){
		List<Ticket> userhistory=ticketRepository.findbyEmail(uid);
		if(userhistory!=null) {
			
			System.out.println("geting history");
			return new ResponseEntity<List<Ticket>>(userhistory, HttpStatus.OK);
		}
		else {
		return  ResponseEntity.badRequest().body(null);
		}
	}


}
