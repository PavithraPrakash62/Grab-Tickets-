package com.edu.eventbooking.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.edu.eventbooking.dao.ApiResponse;
import com.edu.eventbooking.dao.Host;
import com.edu.eventbooking.dao.Shows;
import com.edu.eventbooking.error.GlobalException;
import com.edu.eventbooking.repository.HostRepository;
import com.edu.eventbooking.service.HostService;
import com.edu.eventbooking.service.ShowsService;
@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class HostController {


	@Autowired
	private HostService hostService;


	@Autowired
	private ShowsService showsService;

//
	@Autowired
	private HostRepository hostRepository;


	/*
	http://localhost:8080/registerHost
	 */
	@PostMapping("/registerHost")
	public ResponseEntity<ApiResponse<Host>> registerHost(@RequestBody Host host) {
		Host host_obj = hostRepository.getHostByMobileNumber(host.getMobilenumber());

		if(host_obj != null) {
			ApiResponse<Host> apiResponse = new ApiResponse<>("Host already exists with mobile number : " + host.getMobilenumber(), host_obj);
			return new ResponseEntity<>(apiResponse, HttpStatus.BAD_REQUEST);
		} else {
			Host savedHost = hostService.registerHost(host);
			ApiResponse<Host> apiResponse = new ApiResponse<>("Host saved successfully", savedHost);
			return new ResponseEntity<>(apiResponse, HttpStatus.CREATED);
		}
	}


	/*
	http://localhost:8080/getAllHosts
	 */
	@GetMapping("/getAllHosts")
	public List<Host> getAllHosts(){
		return hostService.getAllHosts();
	}


	/*
	http://localhost:8080/setShowToHost/{showid}/{hostid}
	 */
	@PutMapping("/setShowToHost/{showid}/{hostid}")
	public Shows setShowToHost(@PathVariable("hostid") Integer hostid, @PathVariable("showid") Integer showid) throws GlobalException {
		return showsService.setShowToHost(hostid,showid);
	}


	/*
	http://localhost:8080/updateShowName/{showname}/{hostid}
	 */
	@PutMapping("/updateShowName/{showname}/{hostid}")
	public Shows updateShowName(@PathVariable("showname") String showname, @PathVariable("hostid") Integer hostid) {
		return showsService.updateShowName(showname,hostid);
	}


}
