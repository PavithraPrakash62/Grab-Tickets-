package com.edu.eventbooking.service;

import java.util.List;

import javax.validation.Valid;

import com.edu.eventbooking.dao.Admin;
import com.edu.eventbooking.error.UserNotFoundExceptionHandler;

public interface AdminService {

	public Admin saveAdmin(@Valid Admin admin);

	public Admin updateByAdminId(String adminUserName, @Valid Admin admin) throws UserNotFoundExceptionHandler;

	public List<Admin> getAdmin();

	public Admin findByAdminId(String adminUserName) throws UserNotFoundExceptionHandler;

	public String deleteAdmin();

	public Admin deleteByAdminId(String adminUserName) throws UserNotFoundExceptionHandler;

}
