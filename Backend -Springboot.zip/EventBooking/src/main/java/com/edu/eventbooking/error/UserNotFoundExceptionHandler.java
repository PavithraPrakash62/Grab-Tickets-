package com.edu.eventbooking.error;


public class UserNotFoundExceptionHandler extends Exception {
	
	public UserNotFoundExceptionHandler(String message) {
		super(message);
	}

}
