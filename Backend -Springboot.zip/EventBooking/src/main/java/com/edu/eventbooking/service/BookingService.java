package com.edu.eventbooking.service;

import com.edu.eventbooking.dao.Booking;

public interface BookingService {

	Booking buyTicket(Booking book);

}
