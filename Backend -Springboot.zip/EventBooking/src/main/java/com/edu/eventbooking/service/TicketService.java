package com.edu.eventbooking.service;

import com.edu.eventbooking.dao.Ticket;

public interface TicketService {

	
	

}
