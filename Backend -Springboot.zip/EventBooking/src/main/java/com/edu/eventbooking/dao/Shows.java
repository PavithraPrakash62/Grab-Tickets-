package com.edu.eventbooking.dao;

import java.sql.Date;
import java.sql.Time;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.Future;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;


@Entity
@Table(name="shows")
public class Shows {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer showid;
	
	@Column(nullable = false)
	private String showcategory;
	
	@Column(name="showname",length=70,unique=true,nullable = false)
    @NotBlank(message = "Show name should not be blank")
	private String showname;
	
	@Column(name="showdate",nullable = false)
	@Future(message = "Show date should be in the future")
	private Date showdate;
	
	@Column(name="showtimings",nullable = false)
	private Time showtimings;
	
	@Column(name="costcategory",nullable=false)
	private float costcategory;

		
	@Min(value = 200, message = "Minmum seats should be 200")
	@Max(value= 5000, message = "Maximum seats Shouldn't be more than 5000")
	@Column(nullable = false)
	private int seatcapacity;
	
	@Column(name="Available_seats",nullable = false)
	private int availableseats;

	
	@Column(nullable=false)
	private String showimagepath;
	
	
	@ManyToOne
	private Host host;
	
	@OneToOne
	@JoinColumn(name = "id")
	private Venue venue;
	
	
	
	
	public Shows() {
		super();
		
		
	}
	
	public Shows( String showname,String showcategory, Date showdate, Time showtimings, float costcategory, int seatcapacity,
			int availableseats, String showimagepath) {
		super();
		this.showname = showname;
		this.showcategory=showcategory;
		this.showdate = showdate;
		this.showtimings = showtimings;
		this.costcategory = costcategory;		
		this.seatcapacity=seatcapacity;
		this.availableseats=availableseats;
		this.showimagepath=showimagepath;
	}

	public Integer getShowid() {
		return showid;
	}

	public void setShowid(Integer showid) {
		this.showid = showid;
	}

	public String getShowcategory() {
		return showcategory;
	}

	public void setShowcategory(String showcategory) {
		this.showcategory = showcategory;
	}

	public String getShowname() {
		return showname;
	}

	public void setShowname(String showname) {
		this.showname = showname;
	}

	public Date getShowdate() {
		return showdate;
	}

	public void setShowdate(Date showdate) {
		this.showdate = showdate;
	}

	public Time getShowtimings() {
		return showtimings;
	}

	public void setShowtimings(Time showtimings) {
		this.showtimings = showtimings;
	}

	public float getCostcategory() {
		return costcategory;
	}

	public void setCostcategory(float costcategory) {
		this.costcategory = costcategory;
	}

	public int getAvailableseats() {
		return availableseats;
	}

	public void setAvailableseats(int availableseats) {
		this.availableseats = availableseats;
	}

	public int getSeatcapacity() {
		return seatcapacity;
	}

	public void setSeatcapacity(int seatcapacity) {
		this.seatcapacity = seatcapacity;
	}

	public Host getHost() {
		return host;
	}

	public void setHost(Host host) {
		this.host = host;
	}

	public Venue getVenue() {
		return venue;
	}

	public void setVenue(Venue venue) {
		this.venue = venue;
	}

	public String getShowimagepath() {
		return showimagepath;
	}

	public void setShowimagepath(String showimagepath) {
		this.showimagepath = showimagepath;
	}
	

	@Override
	public String toString() {
		return "Shows [showid=" + showid + ", showcategory=" + showcategory + ", showname=" + showname + ", showdate="
				+ showdate + ", showtimings=" + showtimings + ", costcategory=" + costcategory + ", availableseats="
				+ availableseats + ", seatcapacity=" + seatcapacity + ", showimagepath=" + showimagepath + ", host="
				+ host + ", venue=" + venue + "]";
	}

	
	

	

}
