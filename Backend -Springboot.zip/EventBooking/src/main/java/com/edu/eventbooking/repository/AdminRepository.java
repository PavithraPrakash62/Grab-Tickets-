package com.edu.eventbooking.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.edu.eventbooking.dao.Admin;

@Repository
public interface AdminRepository extends JpaRepository<Admin, Integer>{
	
	
	@Query(value = "select * from admin where admin_user_name=?", nativeQuery = true)
	Admin getAdminByUserName(String adminUserName);


}
