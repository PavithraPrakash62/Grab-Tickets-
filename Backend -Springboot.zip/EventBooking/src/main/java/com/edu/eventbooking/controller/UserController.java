package com.edu.eventbooking.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.edu.eventbooking.dao.ApiResponse;
import com.edu.eventbooking.dao.User;
import com.edu.eventbooking.error.GlobalException;
import com.edu.eventbooking.repository.UserRepository;
import com.edu.eventbooking.service.UserService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class UserController {
	
	
	@Autowired
	private UserService userService;

	
	@Autowired
	private UserRepository userRepository;

	
	// Register user details
	@PostMapping("/addUser")
	public ResponseEntity<User> registerUser(@Valid @RequestBody User user){
		System.out.println(user);
		User checkuser=userRepository.getDetailsByMobile(user.getMobilenumber());
		if(checkuser!=null) {
			
			return  ResponseEntity.badRequest().body(null);
			
		} else {
			User newUser=userRepository.save(user);
//			User savedUser = userService.registerUser(user);
			
			return new ResponseEntity<>(newUser, HttpStatus.CREATED);
		}
	}

	
	@GetMapping("/checkUserByPass/{umail}/{pass}")
	private ResponseEntity<User> checkUserByPass(@Valid @PathVariable("umail") String mail,@PathVariable("pass") String pass) {
		User existinguser=userRepository.getUserByMailPass(mail,pass);

		if ( existinguser!= null) {
			System.out.println("User exists");
			return new ResponseEntity<User>(existinguser, HttpStatus.OK); 
			// Return an error response if already registered
		}
		else  return ResponseEntity.badRequest().body(null); 
	}


	@PutMapping("/updateUser/{id}")
	public ResponseEntity<User> updateUser(@PathVariable("id") Integer userid, @Valid @RequestBody User user ) throws GlobalException {
		
		User user_obj = userRepository.findById(userid).get();
		if(user_obj!=null) {
			System.out.println("updating");
			user_obj.setUsername(user.getUsername());
			user_obj.setFirstname(user.getFirstname());
			user_obj.setLastname(user.getLastname());
			user_obj.setEmail(user.getEmail());
			user_obj.setDob(user.getDob());
			user_obj.setPassword(user.getPassword());
			user_obj.setGender(user.getGender());
		userRepository.save(user_obj);
		User updatedUser=userRepository.findById(userid).get();	
		return new ResponseEntity<>(updatedUser, HttpStatus.OK);
		} else {
			return ResponseEntity.badRequest().body(null); 

		}
	}
	
	
	@GetMapping("/getAllUsers")
	public java.util.List<User> getAllUsers() {
		return userService.getAllusers();
	}
	
	
	@PutMapping("/updatePassword/{mobile}/{oldpass}/{newpass}")
	public ResponseEntity<User> updatePassword(@PathVariable("mobile") String mobilenumber, @PathVariable("oldpass") String oldpass, @PathVariable("newpass") String newpass) throws GlobalException {
		User user_obj = userRepository.getDetailsByMobile(mobilenumber);
		if(user_obj!=null) {
			User savedUser = userService.updatePassword(mobilenumber,oldpass,newpass);
					return new ResponseEntity<>(savedUser, HttpStatus.ACCEPTED);
		} else {
			return ResponseEntity.badRequest().body(null);
		}
	}
	
	@GetMapping("/getUserbyId/{id}")
	public ResponseEntity<User> getUserbyId(@PathVariable("id") Integer userid){

		User user_obj = userRepository.findById(userid).get();
		if(user_obj!=null) {
			System.out.println("Getting getUserbyId");
			return new ResponseEntity<User>(user_obj, HttpStatus.OK);
		}
		else {
			return ResponseEntity.badRequest().body(null); 

		}
		
	}
	
	public ResponseEntity<User> getUserByEmail(@PathVariable("email") String email){
		User user=userRepository.findbyEmail(email);
		if(user!=null) {
			System.out.println("sending");
			return new ResponseEntity<User>(user,HttpStatus.OK);
		}
		else
		{
			return ResponseEntity.badRequest().body(null);
		}
	}


}
