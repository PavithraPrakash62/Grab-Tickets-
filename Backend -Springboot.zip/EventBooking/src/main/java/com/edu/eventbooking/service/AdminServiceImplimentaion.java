package com.edu.eventbooking.service;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.edu.eventbooking.dao.Admin;
import com.edu.eventbooking.error.UserNotFoundExceptionHandler;
import com.edu.eventbooking.repository.AdminRepository;

@Service
public class AdminServiceImplimentaion implements AdminService{

	@Autowired
	private AdminRepository adminRepository;

	@Override
	public Admin saveAdmin(Admin admin) {
		return adminRepository.save(admin);
	}

	@Override
	public Admin updateByAdminId(String adminUserName, @Valid Admin admin) throws UserNotFoundExceptionHandler {
		Admin adminObj = adminRepository.getAdminByUserName(adminUserName);

		if(adminObj != null) {
			adminObj.setAdminUserName(admin.getAdminUserName());
			adminObj.setAdminPassword(admin.getAdminPassword());
			adminRepository.save(adminObj);
			return adminObj;
		} else {
			throw new UserNotFoundExceptionHandler("User not found with User Name : " + adminUserName);
		}
	}

	@Override
	public List<Admin> getAdmin() {
		return adminRepository.findAll();
	}

	@Override
	public Admin findByAdminId(String adminUserName) throws UserNotFoundExceptionHandler {
		Admin adminObj = adminRepository.getAdminByUserName(adminUserName);

		if(adminObj != null) {
			return adminObj;
		} else {
			throw new UserNotFoundExceptionHandler("User not found with User Name : " + adminUserName);
		}
	}

	@Override
	public String deleteAdmin() {
		adminRepository.deleteAll();
		return "Deleted All Data";
	}

	@Override
	public Admin deleteByAdminId(String adminUserName) throws UserNotFoundExceptionHandler {

		Admin adminObj = adminRepository.getAdminByUserName(adminUserName);
		
		if(adminObj != null) {
			adminRepository.delete(adminObj);
			return  null;
		} else {
			throw new UserNotFoundExceptionHandler("User not found with User Name : " + adminUserName);
		}	
	}


}
