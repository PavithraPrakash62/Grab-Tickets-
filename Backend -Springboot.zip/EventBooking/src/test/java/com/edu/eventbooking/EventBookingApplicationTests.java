package com.edu.eventbooking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EventBookingApplicationTests {

	@Test
	void contextLoads() {
	}

}
